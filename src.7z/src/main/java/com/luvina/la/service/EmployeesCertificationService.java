/*
 * Copyright(C) 2023 Luvina Software Company
 *
 * EmployeeController.java, July 10, 2023 nvduc
 */
package com.luvina.la.service;
/**
* Cung cấp các phương thức truy xuất employeeCertification
* @author nvduc
*/
public interface EmployeesCertificationService {
}
