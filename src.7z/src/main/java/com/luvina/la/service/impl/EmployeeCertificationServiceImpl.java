/*
 * Copyright(C) 2023 Luvina Software Company
 *
 * EmployeeController.java, July 10, 2023 nvduc
 */
package com.luvina.la.service.impl;

import org.springframework.stereotype.Service;
/**
 *Xu ly các thông tin liên quan đến employeeCertification
 * @author nvduc
 */
@Service
public class EmployeeCertificationServiceImpl {
}
